//O JavaDoc dessa classe foi gerado com auxílio de uma IA generativa (GPT-4o)
package lab02.exceptions;

/**
 * Exceção lançada quando um endereço de email é inválido.
 */
public class EnderecoEmailInvalidoException extends Exception {
    public EnderecoEmailInvalidoException(String mensagem) {
        super(mensagem);
    } 
}
