//O JavaDoc dessa classe foi gerado com auxílio de uma IA generativa (GPT-4o)
package lab02.exceptions;

/**
 * Exceção lançada quando um ingresso está esgotado.
 */
public class IngressoEsgotadoException extends Exception {
    public IngressoEsgotadoException(String message) {
        super(message);
    } 
}
