//O JavaDoc dessa classe foi gerado com auxílio de uma IA generativa (GPT-4o)

package lab02.exceptions;

/**
 * Exceção lançada quando um local não está disponível.
 */
public class LocalIndisponivelException extends Exception {
    public LocalIndisponivelException(String message) {
        super(message);
    }
}
