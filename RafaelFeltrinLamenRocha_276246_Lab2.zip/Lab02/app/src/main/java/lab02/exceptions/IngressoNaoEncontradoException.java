//O JavaDoc dessa classe foi gerado com auxílio de uma IA generativa (GPT-4o)

package lab02.exceptions;

/**
 * Exceção lançada quando um ingresso não é encontrado.
 */
public class IngressoNaoEncontradoException extends Exception {
    public IngressoNaoEncontradoException(String message) {
        super(message);
    }
}
